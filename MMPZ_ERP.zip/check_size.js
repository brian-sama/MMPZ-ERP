const fs = require('fs');
const lines = fs.readFileSync('tar_list.txt', 'utf8').split('\n');
const files = lines.filter(Boolean).map(l => {
  const parts = l.trim().split(/\s+/);
  // tar -tvf output: -rw-r--r-- 0/0 1234 2023-01-01 12:00 path/to/file
  // parts[2] is size, parts[5+] is path
  return { size: parseInt(parts[2]), name: parts.slice(5).join(' ') };
}).filter(f => !isNaN(f.size));
files.sort((a,b) => b.size - a.size);
console.log(files.slice(0, 20).map(f => `${(f.size/1024/1024).toFixed(2)} MB - ${f.name}`).join('\n'));
