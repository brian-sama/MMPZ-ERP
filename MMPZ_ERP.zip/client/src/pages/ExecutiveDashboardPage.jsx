import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import API_BASE from '../apiConfig';
import PageHeader from '../components/PageHeader';
import {
    LayoutDashboard, Users, FolderKanban, TrendingUp,
    AlertCircle, CheckCircle2, Layers, Clock, ArrowUpRight
} from 'lucide-react';

export default function ExecutiveDashboardPage() {
    const { user } = useAuth();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchDashboard = async () => {
            try {
                const res = await axios.get(`${API_BASE}/dashboard/executive-summary`, {
                    params: { userId: user.id }
                });
                setData(res.data);
            } catch (err) {
                setError('Failed to load dashboard metrics');
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchDashboard();
    }, [user.id]);

    if (loading) return <div className="page-loading"><div className="spinner"></div><p>Loading metrics...</p></div>;
    if (error) return <div className="panel"><div className="auth-error">{error}</div></div>;

    return (
        <div className="fade-in">
            <PageHeader
                title="Executive Dashboard"
                subtitle="Strategic overview of program performance and financial health."
            />

            {/* KPI Row */}
            {/* KPI Row */}
            <div className="kpi-grid">
                <div className="kpi-card accent" style={{ animationDelay: '0.05s' }}>
                    <div className="kpi-top" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '14px' }}>
                        <div className="kpi-icon-wrap" style={{ background: 'rgba(56, 189, 248, 0.15)', color: 'var(--accent-primary)' }}>
                            <Layers size={20} />
                        </div>
                        <div className="kpi-trend up" style={{ fontSize: '11px', fontWeight: 700, color: 'var(--success)', background: 'rgba(16, 185, 129, 0.1)', padding: '2px 8px', borderRadius: '12px' }}>
                            ↑ 12%
                        </div>
                    </div>
                    <div className="kpi-value">{data.active_programs}</div>
                    <div className="kpi-label" style={{ fontSize: '11px', letterSpacing: '0.05em' }}>Active Programs</div>
                    <div className="kpi-sub" style={{ opacity: 0.7 }}>{data.active_projects} Projects currently live</div>
                    <div className="kpi-mini-bar" style={{ height: '3px', background: 'var(--border-subtle)', borderRadius: '2px', marginTop: '12px' }}>
                        <div style={{ width: '70%', height: '100%', background: 'linear-gradient(90deg, var(--accent-secondary), var(--accent-vibrant))', borderRadius: '2px' }}></div>
                    </div>
                </div>

                <div className="kpi-card info" style={{ animationDelay: '0.1s' }}>
                    <div className="kpi-top" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '14px' }}>
                        <div className="kpi-icon-wrap" style={{ background: 'rgba(16, 185, 129, 0.15)', color: 'var(--success)' }}>
                            <Users size={20} />
                        </div>
                    </div>
                    <div className="kpi-value">{data.active_facilitators}</div>
                    <div className="kpi-label" style={{ fontSize: '11px', letterSpacing: '0.05em' }}>Dev Facilitators</div>
                    <div className="kpi-sub" style={{ opacity: 0.7 }}>In-field deployment team</div>
                    <div className="kpi-mini-bar" style={{ height: '3px', background: 'var(--border-subtle)', borderRadius: '2px', marginTop: '12px' }}>
                        <div style={{ width: '85%', height: '100%', background: 'linear-gradient(90deg, var(--success), #34d399)', borderRadius: '2px' }}></div>
                    </div>
                </div>

                <div className="kpi-card success" style={{ animationDelay: '0.15s' }}>
                    <div className="kpi-top" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '14px' }}>
                        <div className="kpi-icon-wrap" style={{ background: 'rgba(245, 158, 11, 0.15)', color: 'var(--warning)' }}>
                            <TrendingUp size={20} />
                        </div>
                        <div className="kpi-trend up" style={{ fontSize: '11px', fontWeight: 700, color: 'var(--success)', background: 'rgba(16, 185, 129, 0.1)', padding: '2px 8px', borderRadius: '12px' }}>
                            ↑ 4%
                        </div>
                    </div>
                    <div className="kpi-value">{data.budget_utilization_percent}%</div>
                    <div className="kpi-label" style={{ fontSize: '11px', letterSpacing: '0.05em' }}>Budget Utilization</div>
                    <div className="kpi-sub" style={{ opacity: 0.7 }}>${data.budget_remaining.toLocaleString()} Available</div>
                    <div className="kpi-mini-bar" style={{ height: '3px', background: 'var(--border-subtle)', borderRadius: '2px', marginTop: '12px' }}>
                        <div style={{ width: `${data.budget_utilization_percent}%`, height: '100%', background: 'linear-gradient(90deg, var(--warning), #fbbf24)', borderRadius: '2px' }}></div>
                    </div>
                </div>

                <div className="kpi-card danger" style={{ animationDelay: '0.2s' }}>
                    <div className="kpi-top" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '14px' }}>
                        <div className="kpi-icon-wrap" style={{ background: 'rgba(167, 139, 250, 0.15)', color: 'var(--purple)' }}>
                            <AlertCircle size={20} />
                        </div>
                    </div>
                    <div className="kpi-value">{data.pending_approvals}</div>
                    <div className="kpi-label" style={{ fontSize: '11px', letterSpacing: '0.05em' }}>Pending Approvals</div>
                    <div className="kpi-sub" style={{ opacity: 0.7 }}>Awaiting executive action</div>
                    <div className="kpi-mini-bar" style={{ height: '3px', background: 'var(--border-subtle)', borderRadius: '2px', marginTop: '12px' }}>
                        <div style={{ width: '40%', height: '100%', background: 'linear-gradient(90deg, var(--purple), #c4b5fd)', borderRadius: '2px' }}></div>
                    </div>
                </div>
            </div>

            <div className="panels-row">
                {/* Approvals Preview */}
                <div className="panel">
                    <div className="panel-header">
                        <div>
                            <h2 className="panel-title">Pending Approvals Queue</h2>
                            <p className="panel-subtitle">Top actionable items across all modules</p>
                        </div>
                        <button className="btn btn-ghost btn-sm" onClick={() => window.location.hash = '/governance'}>
                            View All <ArrowUpRight size={14} />
                        </button>
                    </div>

                    {data.pending_approvals_list?.length > 0 ? (
                        <div className="data-table-wrap">
                            <table className="data-table">
                                <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>Requester</th>
                                        <th>Date</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {data.pending_approvals_list.map(item => (
                                        <tr key={item.id}>
                                            <td><span className="badge badge-info">{item.request_type.replace('_', ' ')}</span></td>
                                            <td>{item.requester_name}</td>
                                            <td>{new Date(item.created_at).toLocaleDateString()}</td>
                                            <td style={{ textAlign: 'right' }}>
                                                <button className="btn btn-primary btn-sm">Review</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <div className="empty-state">
                            <div className="empty-state-icon"><CheckCircle2 size={32} /></div>
                            <div className="empty-state-title">Queue is clear</div>
                            <p className="empty-state-text">No pending items requiring your attention.</p>
                        </div>
                    )}
                </div>

                {/* Key Indicators Snippet */}
                <div className="panel">
                    <div className="panel-header">
                        <div>
                            <h2 className="panel-title">M&E Snapshot</h2>
                            <p className="panel-subtitle">Performance of key organizational indicators</p>
                        </div>
                    </div>

                    <div className="data-table-wrap">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Indicator</th>
                                    <th>Progress</th>
                                    <th>Priority</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.key_indicators?.map((ind, idx) => (
                                    <tr key={idx}>
                                        <td style={{ maxWidth: '200px' }}>
                                            <div style={{ fontWeight: 700, fontSize: '13px', color: 'var(--text-primary)', fontFamily: 'var(--font-heading)' }}>{ind.title}</div>
                                            <div className="form-hint" style={{ fontSize: '11px' }}>{ind.current_value} / {ind.target_value} completed</div>
                                        </td>
                                        <td>
                                            <div style={{ width: '120px' }}>
                                                <div className="progress-bar-wrap" style={{ height: '5px', background: 'var(--border-subtle)', marginBottom: '4px' }}>
                                                    <div
                                                        className="progress-bar-fill"
                                                        style={{
                                                            width: `${ind.progress_percentage}%`,
                                                            background: ind.progress_percentage > 75 ? 'var(--success)' : ind.progress_percentage > 40 ? 'var(--warning)' : 'var(--danger)',
                                                            boxShadow: `0 0 10px ${ind.progress_percentage > 75 ? 'rgba(16, 185, 129, 0.3)' : ind.progress_percentage > 40 ? 'rgba(245, 158, 11, 0.3)' : 'rgba(244, 63, 94, 0.3)'}`
                                                        }}
                                                    ></div>
                                                </div>
                                                <div style={{ fontSize: '10px', fontWeight: 700, color: 'var(--text-muted)' }}>{ind.progress_percentage}% Optimized</div>
                                            </div>
                                        </td>
                                        <td>
                                            <span className={`badge badge-${ind.priority === 'critical' ? 'danger' : ind.priority === 'high' ? 'warning' : 'primary'}`} style={{ borderRadius: '6px', fontSize: '9px' }}>
                                                {ind.priority.toUpperCase()}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div style={{ textAlign: 'center', marginTop: '24px', fontSize: '11px', color: 'var(--text-muted)' }}>
                <Clock size={12} style={{ verticalAlign: 'middle', marginRight: '4px' }} />
                Last full update: {new Date(data.updated_at).toLocaleString()}
            </div>
        </div>
    );
}
