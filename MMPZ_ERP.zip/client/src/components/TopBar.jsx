import React, { useState } from 'react';
import { Bell, Search, User, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function TopBar({ onToggleSidebar, title }) {
    const { user, logout } = useAuth();
    const [showNotifications, setShowNotifications] = useState(false);

    return (
        <header className="erp-topbar">
            <div className="topbar-title">{title}</div>

            <div className="topbar-actions">
                <button className="topbar-btn" data-tooltip="Search">
                    <Search size={18} />
                </button>

                <button
                    className="topbar-btn"
                    data-tooltip="Notifications"
                    onClick={() => setShowNotifications(!showNotifications)}
                >
                    <Bell size={18} />
                    {/* Example badge */}
                    <span className="topbar-badge">3</span>
                </button>

                <div className="divider" style={{ width: '1px', height: '24px', margin: '0 8px', background: 'var(--border)' }}></div>

                <div className="sidebar-user-avatar" style={{ width: '30px', height: '30px', fontSize: '12px' }}>
                    {(user?.name || 'U')[0].toUpperCase()}
                </div>
            </div>
        </header>
    );
}
